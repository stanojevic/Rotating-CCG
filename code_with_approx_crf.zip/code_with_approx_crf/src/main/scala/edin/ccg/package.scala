package edin

import edin.ccg.representation.tree.TreeNode


package object ccg {

  val PROGRAM_NAME = "CCG_Revelation"
  val PROGRAM_VERSION = 0.1

  type TrainInstance = TreeNode

}
