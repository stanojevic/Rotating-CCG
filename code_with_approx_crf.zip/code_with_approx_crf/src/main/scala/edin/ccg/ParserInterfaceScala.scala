package edin.ccg

import edin.ccg.parsing.{Parser, RevealingModel}
import edin.ccg.representation.combinators.Combinator
import edin.ccg.representation.predarg.{DepLink, PredArg}
import edin.general.PTBtokenizer
import edin.nn.DynetSetup

import scala.collection.JavaConverters._

final case class ParseResultForJava(
                                     tokens: java.util.List[String],
                                     tree  : String,
                                     deps  : java.util.List[DepLink]
                                   )

class ParserInterfaceScala(modelDir:String, language:String="English", beamSize:Int=4, tokenization:Boolean=true) {

  ParserInterfaceScala.initDynet()
  Combinator.setLanguage(language, null)
  PredArg.includeConjunctInDeps = true

  val models = List(modelDir).map { modelDir =>
    val model = new RevealingModel()
    model.loadFromModelDir(modelDir)
    model
  }

  def parse(sents:java.util.List[String]) : java.util.List[ParseResultForJava] =
    parse(sents.asScala.toList).map{ case (tokens, tree, deps) =>
      ParseResultForJava(
        tokens = tokens.asJava,
        tree   = tree,
        deps   = deps.asJava
      )
    }.asJava

  def parse(sents:List[String]) : List[(List[String], String, List[DepLink])] =
    sents.map{ sent =>
      val words = if(tokenization) PTBtokenizer.tokenize(sent) else sent.split(" +").toList
      val tree = Parser.parse(
        sent = words,
        beamType     = "simple",
        beamRescaled = false,
        kMidParsing  = beamSize,
        kOutParsing  = beamSize,
        kOutWord     = beamSize,
        kOutTagging  = beamSize,
        maxStackSize = Integer.MAX_VALUE
      )(models)
      (words, tree.toCCGbankString, tree.deps())
    }

}

object ParserInterfaceScala{

  private var initialized = false

  private def initDynet() : Unit =
    if(!initialized){
      DynetSetup.init_dynet(
        dynet_mem = null,
        autobatch = 0)
      initialized = true
    }

}

