package edin.ccg

import edin.ccg.representation.DerivationsLoader
import edin.ccg.representation.category.Category
import edin.ccg.representation.tree.{BinaryNode, TerminalNode, TreeNode, UnaryNode}

object MainPlayground {

  def main(args: Array[String]): Unit = {

    val file = "/home/milos/Projects/CCG-translator/tmp/ccg_extracted/toy3.trees"

    val trees = DerivationsLoader.fromFile(file).toList
    val table = createNonTerminalTable(trees)
    val rules = findAllTheRules(trees, table)

    println(rules.mkString("\n"))

    for(tree <- trees){
      println(tree2string(tree, table))
    }

  }

  def findAllTheRules(trees: List[TreeNode], table:Map[Category, String]) : Set[String] =
    trees.toStream.flatMap(_.allNodes).flatMap{
      case node@UnaryNode(_, child) =>
        Some(  table(node.category)+" -> "+table(child.category)   )
      case node@BinaryNode(_, left, right) =>
        Some(  table(node.category)+" -> "+table(left.category)+" "+table(right.category)   )
      case _ =>
        None
    }.toSet

  def createNonTerminalTable(trees:Seq[TreeNode]) : Map[Category, String] =
    {for(tree <- trees.toStream ; node <- tree.allNodes) yield node.category}.
    distinct.
    toList.
    sortBy(_.toString).
    zipWithIndex.
    map{case (category, index) => (category -> s"NT$index") }.
    toMap

  def tree2string(node:TreeNode, table:Map[Category, String]) : String = node match {
    case UnaryNode(_, child) => "("+table(node.category)+" "+tree2string(child, table)+")"
    case BinaryNode(_, left, right) => "("+table(node.category)+" "+tree2string(left, table)+" "+tree2string(right, table)+")"
    case TerminalNode(word, category) => s"(${table(category)} $word)"
  }

}
