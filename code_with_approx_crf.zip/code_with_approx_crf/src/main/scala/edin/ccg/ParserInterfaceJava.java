package edin.ccg;

import edin.ccg.representation.predarg.DepLink;

import java.util.ArrayList;
import java.util.List;

public class ParserInterfaceJava {

    public static void main(String[] args){
        List<String> sents = new ArrayList<>();
        sents.add("This is the first sentence.");
        sents.add("This is one more sentence that is different.");
        // /home/milos/Projects/CCG-translator/models/best_model
        ParserInterfaceScala parser = new ParserInterfaceScala("./models/best_model", "English", 1, true);

        List<ParseResultForJava> results = parser.parse(sents);

        for(ParseResultForJava result: results){
            System.out.println("This is a tokenized sentence "+result.tokens());
            for(DepLink dep : result.deps()){
                System.out.println(dep);
            }
            System.out.println();
        }
    }

}
