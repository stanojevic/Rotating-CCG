package edin.ccg.representation.transforms

import edin.ccg.representation.category.{Category, Functor, Slash}
import edin.ccg.representation.combinators._
import edin.ccg.representation.transforms.AdjunctionGeneral.RightAdjoinCombinator
import edin.ccg.representation.tree._

import scala.util.{Failure, Try}

object Rebranching {

  var newRevealing : Boolean = true

  def main(args:Array[String]) : Unit = {
    import edin.ccg.representation.DerivationsLoader
    Combinator.setLanguage("English", null)

    val trees: Iterator[TreeNode] = DerivationsLoader.fromFile("./tmp/ccg_extracted/train.trees")

    var errCounter = 0
    for((tree, i) <- trees.zipWithIndex){
      Try(tree.toRevealingBranching.toRightBranching) match {
        case Failure(exception) =>
          errCounter += 1
          println(exception)
          exception.printStackTrace()
          println(s"errors $errCounter")
          tree.visualize(s"    tree number $i     ")
        case _ =>
      }
      println(i)
    }
    println(s"errors $errCounter")
  }

  def toRightBranching(node:TreeNode) : TreeNode = node match {
    case BinaryNode(c, l, r) =>
      sinkRightward(BinaryNode(c, toRightBranching(l), toRightBranching(r)))
    case UnaryNode(c, child) =>
      sinkRightward(UnaryNode(c, toRightBranching(child)))
    case TerminalNode(_, _) =>
      node
  }

  def toLeftBranchingSimplistic(node:TreeNode) : TreeNode = node match {
    case BinaryNode(c, l, r) =>
      sinkLeftward(BinaryNode(c, toLeftBranchingSimplistic(l), toLeftBranchingSimplistic(r)))
    case UnaryNode(c, child) =>
      UnaryNode(c, toLeftBranchingSimplistic(child))
    case _ =>
      node
  }

  ///////////////////////////////// Transform:  remove unneeded Type-Raising /////////////////////

  private def removeUnneededTypeRaisingSingle : TreeNode => TreeNode = {
    case BinaryNode(B0bck(), left, UnaryNode(TypeRaiser(_, _, Slash.BCK, true), right)) if Rebranching.newRevealing =>
      BinaryNode(B0fwd(), left, right)
    case BinaryNode(B0fwd(), UnaryNode(TypeRaiser(_, _, Slash.FWD, true), left), right) if Rebranching.newRevealing =>
      BinaryNode(B0bck(), left, right)
    case x =>
      x
  }

  private def removeUnneededTypeRaisingForRebalancing(node: TreeNode) : TreeNode = removeUnneededTypeRaisingSingle(node) match {
    case BinaryNode(c, left, right) => BinaryNode(c, removeUnneededTypeRaisingSingle(left), removeUnneededTypeRaisingSingle(right))
    case x => x
  }

  def removeUnneededTypeRaisingRec(node:TreeNode) : TreeNode = removeUnneededTypeRaisingSingle(node) match {
    case BinaryNode(c, left, right) =>
      BinaryNode(c, removeUnneededTypeRaisingRec(left), removeUnneededTypeRaisingRec(right))
    case UnaryNode(c, child) =>
      UnaryNode(c, removeUnneededTypeRaisingSingle(child))
    case x:TerminalNode =>
      x
  }

  ///////////////////////////////// Transform: sink  /////////////////////
  private def attachRightPuncAtBottom(node:TreeNode, punc:TreeNode) : TreeNode = node match {
    case TerminalNode(_, _) => BinaryNode(RemovePunctuation(false), node, punc)
    case BinaryNode(c, l, r) => BinaryNode(c, l, attachRightPuncAtBottom(r, punc))
    case UnaryNode(c, child) => UnaryNode(c, attachRightPuncAtBottom(child, punc))
  }
  def sinkRightward(node:TreeNode) : TreeNode = removeUnneededTypeRaisingForRebalancing(node) match {
    case BinaryNode(RightAdjoinCombinator(span, cat), left, right) =>
      // adjunction rule
      RightSpine.rightModify(left, right, span, cat)
    case BinaryNode(B0fwd(), BinaryNode(B0bck(), a1, a2), a3) if newRevealing =>
      // rule 5
      val res = for{
        tr   <- CombinatorUnary.allPredefinedTypeRaiseLookup(false, a3.category, node.category)
        tree <- Try( BinaryNode(B0bck(), a1, BinaryNode(B1bck(false), a2, UnaryNode(tr, a3))) ).toOption
        if tree.category == node.category
      } yield tree
      res.getOrElse(node)
    case BinaryNode(b:Backwards, l@BinaryNode(B0fwd(), a1, a2), a3) if b.order < Backwards.maxB && newRevealing =>
      // rule 4
      val res = for{
        tr   <- CombinatorUnary.allPredefinedTypeRaiseLookup(false, a2.category, l.category)
        tree <- Try( BinaryNode(B0bck(), a1, BinaryNode(Backwards.b_harmonic(b.order+1), UnaryNode(tr, a2), a3)) ).toOption
        if tree.category == node.category
      } yield tree
      res.getOrElse(node)
    case BinaryNode(B0fwd(), l@BinaryNode(B0fwd(), a1, a2), a3) if newRevealing =>
      // rule 3
      val res = for{
        tr2  <- CombinatorUnary.allPredefinedTypeRaiseLookup(false, a2.category,    l.category)
        tr3  <- CombinatorUnary.allPredefinedTypeRaiseLookup(false, a3.category, node.category)
        tree <- Try( BinaryNode(B0bck(), a1, BinaryNode(B1bck(false), UnaryNode(tr2, a2), UnaryNode(tr3, a3))) ).toOption
        if tree.category == node.category
      } yield tree
      res.getOrElse(node)
    case UnaryNode(c, BinaryNode(RemovePunctuation(true), l, r)) =>
      // rule sink unary to right when punction is to the left
      BinaryNode(RemovePunctuation(true), l, UnaryNode(c, r))
    case BinaryNode(Glue(), BinaryNode(Glue(), a1, a2), a3) =>
      // glue rule rotation
      BinaryNode(Glue(), a1, sinkRightward(BinaryNode(Glue(), a2, a3)))
    case BinaryNode(Glue(), l, r) =>
      // end of glue rule rotation
      BinaryNode(Glue(), l, sinkRightward(r))
    case BinaryNode(c, BinaryNode(RemovePunctuation(true), a1, a2), a3) =>
      // raise left punctuation
      BinaryNode(RemovePunctuation(true), a1, sinkRightward(BinaryNode(c, a2, a3)))
    case BinaryNode(RemovePunctuation(false), l, r) =>
      // lower right punctuation
      attachRightPuncAtBottom(l, r)
    case BinaryNode(high:Backwards, BinaryNode(low:Backwards, a1, a2), a3) if newRevealing =>
      // rule 2
      // TODO special recursion TODO
      val x = high.order
      val y = low.order
      val m = Backwards.maxB
      if(x>=y && x-y+1<=m){
        val bLow  = if(Backwards.b_harmonic(x-y+1).canApply(a2.category, a3.category)) Backwards.b_harmonic(x-y+1) else Backwards.b_crossed(x-y+1)
        val bHigh = low // if(low.isHarmonic ) Backwards.b_harmonic(y) else Backwards.b_crossed(y)
        Try(    sinkRightward(BinaryNode(bHigh, a1, sinkRightward(BinaryNode(bLow, a2, a3))))   ).getOrElse(node)
      }else{
        node
      }
    case BinaryNode(high:Forwards, BinaryNode(low:Forwards, a1, a2), a3) =>
      // rule 1
      val x = high.order
      val y = low.order
      val m = Forwards.maxB
      if(y!=0 && x+y-1<=m)
        sinkRightward(BinaryNode(Forwards.b(x+y-1), a1, sinkRightward(BinaryNode(Forwards.b(x), a2, a3))))
      else
        node
    case BinaryNode(RemovePunctuation(true), l, r) =>
      // just continue on the right node when left node is a high punctuation
      BinaryNode(RemovePunctuation(true), l, sinkRightward(r))
    case _ =>
      node
  }

  def sinkLeftward(node:TreeNode) : TreeNode = removeUnneededTypeRaisingForRebalancing(node) match {
    case BinaryNode(B0bck(), a1, BinaryNode(B0fwd(), a2, a3)) =>
      // rule 5
      val res = for{
        tr   <- CombinatorUnary.allPredefinedTypeRaiseLookup(true, a1.category, node.category)
        tree <- Try( BinaryNode(B0fwd(), BinaryNode(B1fwd(), UnaryNode(tr, a1), a2), a3) ).toOption
        if tree.category == node.category
      } yield tree
      res match {
        case Some(BinaryNode(c, l, r)) =>
          BinaryNode(c, sinkLeftward(l), r)
        case None =>
          node
      }
//      res.getOrElse(node)
    case BinaryNode(B0bck(), a1, r@BinaryNode(B0bck(), a2, a3)) if newRevealing =>
      // rule 3
      val res = for{
        tr1  <- CombinatorUnary.allPredefinedTypeRaiseLookup(true, a1.category, node.category)
        tr2  <- CombinatorUnary.allPredefinedTypeRaiseLookup(true, a2.category, r.category)
        tree <- Try( BinaryNode(B0fwd(), BinaryNode(Forwards.b(1), UnaryNode(tr1, a1), UnaryNode(tr2, a2)), a3) ).toOption
        if tree.category == node.category
      } yield tree
      res.getOrElse(node)
    case BinaryNode(b:Forwards, a1, r@BinaryNode(B0bck(), a2, a3)) if b.order < Forwards.maxB && newRevealing =>
      // rule 4
      val res = for{
        tr   <- CombinatorUnary.allPredefinedTypeRaiseLookup(true, a2.category, r.category)
        tree <- Try( BinaryNode(B0fwd(), BinaryNode(Forwards.b(b.order+1), a1, UnaryNode(tr, a2)), a3) ).toOption
        if tree.category == node.category
      } yield tree
      res.getOrElse(node)
    case BinaryNode(high:Backwards, a1, BinaryNode(low:Backwards, a2, a3)) if newRevealing =>
      // rule 2
      val x = high.order
      val y = low.order
      val m = Backwards.maxB
      if(y!=0 && x+y-1<=m){
        val bHigh = if(low.isHarmonic && high.isHarmonic) Backwards.b_harmonic(x+y-1) else Backwards.b_crossed(x+y-1)
        val bLow  = if(high.isHarmonic                  ) Backwards.b_harmonic(x    ) else Backwards.b_crossed(x    )
        Try(BinaryNode(bHigh, sinkLeftward(BinaryNode(bLow, a1, a2)), a3)).getOrElse(node)
      }else{
        node
      }
    case BinaryNode(high:Forwards, left, right) =>
      // rule 1
      def rebuild(parentOrder: Int, node:TreeNode) : Option[TreeNode] = node match {
        case BinaryNode(c:Forwards, l, r) if parentOrder>=c.order =>
          (c, l.category) match {
            case (B0fwd(), Functor(_, subcat, _)) if subcat matches Category.NP =>
              None
            case _ =>
              val newOrder = parentOrder-c.order+1
              rebuild(newOrder, l) match {
                case Some(newL) =>
                  Some(BinaryNode(c, newL, r))
                case None if newOrder <= Forwards.maxB =>
                  Some(BinaryNode(c, BinaryNode(Forwards.b(newOrder), left, l), r))
                case None =>
                  None
              }
          }
        case _ =>
          None
      }
      rebuild(high.order, right).getOrElse(node)
    case BinaryNode(c, l, BinaryNode(RemovePunctuation(false), r, punc)) =>
      BinaryNode(RemovePunctuation(false), sinkLeftward(BinaryNode(c, l, r)), punc)
    case BinaryNode(RemovePunctuation(true), punc, BinaryNode(c, l, r)) =>
      BinaryNode(c, PuncAttachment.attachLeftPuncAtBottom(punc, l), r)
    case BinaryNode(RemovePunctuation(true), punc, UnaryNode(c, child)) =>
      UnaryNode(c, PuncAttachment.attachLeftPuncAtBottom(punc, child))
    case _ =>
      node
  }


}
