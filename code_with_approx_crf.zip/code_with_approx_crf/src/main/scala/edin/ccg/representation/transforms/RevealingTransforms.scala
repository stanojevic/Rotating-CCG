package edin.ccg.representation.transforms

import edin.ccg.representation.combinators._
import edin.ccg.representation.transforms.AdjunctionGeneral.RightAdjoinCombinator
import edin.ccg.representation.tree._
//import edin.general.RichScala._

object RevealingTransforms {

  def addRevealing(node: TreeNode) : TreeNode = {
    var tree = node
    tree = raiseLeftPunctuation(tree)
    tree = lowerAdjunctionWhenModifyingPuncNodeRec(tree)
    tree = fixArgumentClusterCoordination(tree)
    tree = raiseLeftPunctuation(tree)
    tree = lowerAdjunctionWhenModifyingPuncNodeRec(tree)
    tree = addRevealingRec(tree)
    tree
  }

  private def raiseLeftPunctuation(node:TreeNode) : TreeNode = {
    val newNode = node match {
      case BinaryNode(c, left, right) => BinaryNode(c, raiseLeftPunctuation(left), raiseLeftPunctuation(right))
      case UnaryNode(c, child) => UnaryNode(c, raiseLeftPunctuation(child))
      case TerminalNode(_, _) => node
    }
    newNode match {
      case BinaryNode(c, BinaryNode(RemovePunctuation(true), p, a), b) =>
        BinaryNode(RemovePunctuation(true), p, BinaryNode(c, a, b))
      case UnaryNode(c, BinaryNode(RemovePunctuation(true), p, a)) =>
        BinaryNode(RemovePunctuation(true), p, UnaryNode(c, a))
      case x =>
        x
    }
  }

  private def lowerAdjunctionWhenModifyingPuncNodeRec : TreeNode => TreeNode = {
    case node@BinaryNode(c1, BinaryNode(RemovePunctuation(true), p, h), a) if AdjunctionGeneral isRightAdjunctionPlace node  =>
      lowerAdjunctionWhenModifyingPuncNodeRec(BinaryNode(RemovePunctuation(true), p, BinaryNode(c1, h, a)))
    case BinaryNode(c, a, b) =>
      BinaryNode(c, lowerAdjunctionWhenModifyingPuncNodeRec(a), lowerAdjunctionWhenModifyingPuncNodeRec(b))
    case UnaryNode(c, a) =>
      UnaryNode(c, lowerAdjunctionWhenModifyingPuncNodeRec(a))
    case node@TerminalNode(_, _) =>
      node
  }

  private def fixArgumentClusterCoordination(node:TreeNode) : TreeNode = {
//    val (core, conjs) = separateRightConjuncts(PuncAttachment.reattachPunctuationTopLeft(node))
    val (core, conjs) = separateRightConjuncts(node)
    val coreFixed  = Rebranching.toLeftBranchingSimplistic(core)
    val conjsFixed =  conjs.map{case (c, n) => (c, Rebranching.toLeftBranchingSimplistic(n))}

//    val coreFixed  = Rebranching.toRightBranching(core)
//    val conjsFixed =  conjs.map{case (c, n) => (c, Rebranching.toRightBranching(n))}

    val newRoot = conjsFixed.foldLeft(coreFixed){case (core, (comb, adj)) => reattachAdjunctOrPunc(core, comb, adj)}
//    newRoot = PuncAttachment.reattachPunctuationTopLeft(newRoot)
//    newRoot = Rebranching.removeUnneededTypeRaisingRec(newRoot)
//    newRoot = Rebranching.toLeftBranchingSimplistic(newRoot)
    newRoot
  }

  private def separateRightConjuncts(node:TreeNode) : (TreeNode, List[(CombinatorBinary, TreeNode)]) = node match {
    case x: TerminalNode =>
      (x, Nil)
    case UnaryNode(c, child) =>
      val (core, conjs) = separateRightConjuncts(child)
      (UnaryNode(c, core), conjs)
    case BinaryNode(ConjunctionTop(), left, right) =>
      val (coreL, conjsL) = separateRightConjuncts(left)
      val (coreR, conjsR) = separateRightConjuncts(right)
      (coreL, conjsL++List((RightAdjoinCombinator(left.span, coreL.category), coreR))++conjsR)
    case BinaryNode(c, left, right) =>
      val (coreL, conjsL) = separateRightConjuncts(left)
      val (coreR, conjsR) = separateRightConjuncts(right)
      (BinaryNode(c, coreL, coreR), conjsL++conjsR)
  }

  private def addRevealingRec(node:TreeNode) : TreeNode = node match {
    case TerminalNode(_, _) =>
      node
    case UnaryNode(comb, child) =>
      UnaryNode(comb, addRevealingRec(child))
    case BinaryNode(comb, l, r) =>
      if(AdjunctionGeneral.isRightAdjunctionPlace(node))
        BinaryNode(RightAdjoinCombinator(l.span, l.category), addRevealingRec(l), addRevealingRec(r))
      else
        BinaryNode(comb, addRevealingRec(l), addRevealingRec(r))
  }

  private def extractRightAdjunctAndPuncSubtrees(node:TreeNode) : (TreeNode, List[(CombinatorBinary, TreeNode)]) = node match {
    case BinaryNode(comb, left, right) =>
      val (coreLeft, leftRightAdjuncts) = extractRightAdjunctAndPuncSubtrees(left)
      val (coreRight, rightRightAdjuncts) = extractRightAdjunctAndPuncSubtrees(right)
      comb match {
        case RightAdjoinCombinator(_, _) =>
          (coreLeft                             , leftRightAdjuncts ++ rightRightAdjuncts :+ (comb, coreRight) )
        case RemovePunctuation(false) if coreRight.span._2-coreRight.span._1==1  =>
          (coreLeft                             , leftRightAdjuncts ++ rightRightAdjuncts :+ (comb, coreRight) )
        case RemovePunctuation(true)  if coreLeft.span._2-coreLeft.span._1==1    =>
          (coreRight                            , leftRightAdjuncts ++ rightRightAdjuncts :+ (comb, coreLeft ) )
        case _ =>
          (BinaryNode(comb, coreLeft, coreRight), leftRightAdjuncts ++ rightRightAdjuncts)
      }
    case UnaryNode(comb, child) =>
      val (coreChild, rightAdjs) = extractRightAdjunctAndPuncSubtrees(child)
      (UnaryNode(comb, coreChild), rightAdjs)
    case TerminalNode(_, _) =>
      (node, Nil)
  }

  private def reattachAdjunctOrPunc(core:TreeNode, comb: CombinatorBinary, adj:TreeNode) : TreeNode =
    if(core.span._2 == adj.span._1)
      comb match {
        case RemovePunctuation(_) =>
          BinaryNode(RemovePunctuation(false), core, adj)
        case _ =>
          BinaryNode(comb, core, adj)
      }
    else
      core match {
        case BinaryNode(c, l, r) =>
          if(r.span._1<adj.span._1)
            BinaryNode(c, l, reattachAdjunctOrPunc(r, comb, adj))
          else
            BinaryNode(c, reattachAdjunctOrPunc(l, comb, adj), r)
        case UnaryNode(c, child) =>
          UnaryNode(c, reattachAdjunctOrPunc(child, comb, adj))
        case _ =>
          throw new Exception("should be here")
      }

  def toLeftBranchingWithRevealing(root:TreeNode, withLeftBranching:Boolean) : TreeNode = {
    val (coreRoot: TreeNode, rightAdjsAndPuncs: Seq[(CombinatorBinary, TreeNode)]) = extractRightAdjunctAndPuncSubtrees(root)
    val coreRootLefted = if(withLeftBranching) Rebranching.toLeftBranchingSimplistic(coreRoot) else coreRoot
    val rightAdjsAndPuncsLeftedSorted = rightAdjsAndPuncs.map{case (comb, node) => (comb, Rebranching.toLeftBranchingSimplistic(node))}.sortBy(_._2.span)
    val leftPuncCorner:Option[TreeNode] = rightAdjsAndPuncsLeftedSorted.headOption match {
      case Some((RemovePunctuation(_), first)) if first.span._1 == root.span._1 =>
        val corner = rightAdjsAndPuncsLeftedSorted.sliding(2).takeWhile {
          case List((RemovePunctuation(_), x), (RemovePunctuation(_), y)) if x.span._2 == y.span._1 => true
          case _ => false
        }.map {
          _(1)
        }.foldLeft(first) { case (l, (_, r)) => BinaryNode(RemovePunctuation(false), l, r) }
        Some(corner)
      case _ =>
        None
    }
    val rightAdjsAndPuncsLeftedSortedUncornered = leftPuncCorner match {
      case None =>
        rightAdjsAndPuncsLeftedSorted
      case Some(corner) =>
        rightAdjsAndPuncsLeftedSorted.dropWhile(_._2.span._2 <= corner.span._2)
    }

    val coreRootLeftedCornered = leftPuncCorner match {
      case None =>
        coreRootLefted
      case Some(puncCorner) =>
        PuncAttachment.attachLeftPuncAtBottom(puncCorner, coreRootLefted)
      // BinaryNode(RemovePunctuation(true), puncCorner, coreRootLefted)
    }

    val newRoot = rightAdjsAndPuncsLeftedSortedUncornered.foldLeft(coreRootLeftedCornered){case (core, (comb, adj)) => reattachAdjunctOrPunc(core, comb, adj)}
    assert(root.words == newRoot.words)
    newRoot
  }


}
