package edin.ccg.representation.combinators

import edin.ccg.representation.CombinatorsContainer
import edin.ccg.representation.category.{Category, Slash}
import scala.collection.mutable.{Map => MutMap}

object CombinatorUnary{

  def isPredefined(c:CombinatorUnary) : Boolean = allPredefined.contains(c)

  private val a_star_predefined : List[CombinatorUnary] = List[CombinatorUnary](

  // N       NP
    TypeChangeUnary(
      from= Category("N"),
      to= Category("NP") // unary hard coded
    ),

    // # Relativization, as in "the boy playing tennis"
    // S[pss]\NP      NP\NP
    TypeChangeUnary(
      from= Category("""S[pss]\NP"""),
      to= Category("""NP\NP""") // unary hard coded
    ),

    // S[ng]\NP       NP\NP
    TypeChangeUnary(
      from= Category("""S[ng]\NP"""),
      to= Category("""NP\NP""") // unary hard coded
    ),

    // S[adj]\NP      NP\NP
    TypeChangeUnary(
      from= Category("""S[adj]\NP"""),
      to= Category("""NP\NP""") // unary hard coded
    ),
    // S[to]\NP       NP\NP
    TypeChangeUnary(
      from= Category("""S[to]\NP"""),
      to= Category("""NP\NP""") // unary hard coded
    ),
    // S[to]\NP       N\N
    TypeChangeUnary(
      from= Category("""S[to]\NP"""),
      to= Category("""N\N""") // unary hard coded
    ),
    // S[dcl]/NP       NP\NP
    TypeChangeUnary(
      from= Category("""S[dcl]/NP"""),
      to= Category("""NP\NP""") // unary hard coded
    ),

    // # Rules that let verb-phrases modify sentences, as in "Born in Hawaii, Obama is the 44th president."
    // S[pss]\NP      S/S
    TypeChangeUnary(
      from= Category("""S[pss]\NP"""),
      to= Category("""S/S""") // unary hard coded
    ),
    // S[ng]\NP       S/S
    TypeChangeUnary(
      from= Category("""S[ng]\NP"""),
      to= Category("""S/S""") // unary hard coded
    ),
    // S[to]\NP       S/S
    TypeChangeUnary(
      from= Category("""S[to]\NP"""),
      to= Category("""S/S""") // unary hard coded
    ),

    // # Type raising
    // Type raise 1
    // NP      S[X]/(S[X]\NP)
    TypeRaiser(
      fromMatcher = Category("NP"),
      functionResult = Category("S"),
      slash=Slash.FWD,
      orderPreserving = true
    ),
    // Type raise 2
    // NP      (S[X]\NP)\((S[X]\NP)/NP)
    TypeRaiser(
      fromMatcher= Category("NP"),
      functionResult = Category("""S\NP"""),
      slash= Slash.BCK,
      orderPreserving = true
    ),
    // Type raise 3
    // PP      (S[X]\NP)\((S[X]\NP)/PP)
    TypeRaiser(
      fromMatcher = Category("PP"),
      functionResult = Category("""S\NP"""),
      slash = Slash.BCK,
      orderPreserving = true
    )
  )

  // from appendix A of C&C paper
  private val c_and_c_additional : List[CombinatorUnary] = List(
    TypeRaiser(
      fromMatcher= Category("NP"),
      functionResult = Category("""(S\NP)/NP"""),
      slash= Slash.BCK,
      orderPreserving = true
    ),
    TypeRaiser(
      fromMatcher= Category("NP"),
      functionResult = Category("""(S\NP)/PP"""),
      slash= Slash.BCK,
      orderPreserving = true
    ),
    TypeRaiser(
      fromMatcher= Category("NP"),
      functionResult = Category("""(S\NP)/(S[to]\NP)"""),
      slash= Slash.BCK,
      orderPreserving = true
    ),
    TypeRaiser(
      fromMatcher= Category("NP"),
      functionResult = Category("""(S\NP)/(S[adj]\NP)"""),
      slash= Slash.BCK,
      orderPreserving = true
    ),
    TypeRaiser(
      fromMatcher= Category("""S[adj]\NP"""),
      functionResult = Category("""S\NP"""),
      slash= Slash.BCK,
      orderPreserving = true
    ),
    TypeChangeUnary(
      from= Category("""NP"""),
      to= Category("""S/(S/NP)""")
    ),
    TypeChangeUnary(
      from= Category("""NP"""),
      to= Category("""NP/(NP\NP)""")
    ),
    TypeChangeUnary(
      from= Category("""(S[to]\NP)/NP"""),
      to= Category("""NP\NP""")
    ),
    TypeChangeUnary(
      from= Category("""S[dcl]/NP"""),
      to= Category("""NP\NP""")
    ),
    TypeChangeUnary(
      from= Category("""S[dcl]"""),
      to= Category("""NP\NP""")
    ),
    TypeChangeUnary(
      from= Category("""S[pss]\NP"""),
      to= Category("""(S\NP)\(S\NP)""")
    ),
    TypeChangeUnary(
      from= Category("""S[ng]\NP"""),
      to= Category("""(S\NP)\(S\NP)""")
    ),
    TypeChangeUnary(
      from= Category("""S[adj]\NP"""),
      to= Category("""(S\NP)\(S\NP)""")
    ),
    TypeChangeUnary(
      from= Category("""S[to]\NP"""),
      to= Category("""(S\NP)\(S\NP)""")
    ),
    TypeChangeUnary(
      from= Category("""S[ng]\NP"""),
      to= Category("""(S\NP)/(S\NP)""")
    ),
    TypeChangeUnary(
      from= Category("""S[adj]\NP"""),
      to= Category("""S/S""")
    ),
    TypeChangeUnary(
      from= Category("""S[ng]\NP"""),
      to= Category("""S\S""")
    ),
    TypeChangeUnary(
      from= Category("""S[dcl]\NP"""),
      to= Category("""S\S""")
    ),
    TypeChangeUnary(
      from= Category("""S[ng]\NP"""),
      to= Category("""N\N""")
    ),
    TypeChangeUnary(
      from= Category("""S[dcl]"""),
      to= Category("""S\S""")
    ),
    TypeChangeUnary(
      from= Category("""S[dcl]\NP"""),
      to= Category("""S\S""")
    ),
    TypeChangeUnary(
      from= Category("""S[ng]\NP"""),
      to= Category("""NP""")
    )
  )

  private val chinese_predefined : List[CombinatorUnary] = List[CombinatorUnary](
    TypeRaiser(
      fromMatcher = Category("NP"),
      functionResult = Category("S"),
      slash=Slash.FWD,
      orderPreserving = true
    ),
    TypeRaiser(
      fromMatcher = Category("NP"),
      functionResult = Category("S"),
      slash=Slash.FWD,
      orderPreserving = false
    ),
    TypeChangeUnary(
      from= Category("""S[dcl]\NP"""),
      to= Category("""S[dcl]""")
    ),
    TypeChangeUnary(
      from= Category("""NP"""),
      to= Category("""S/S""")
    ),
    TypeChangeUnary(
      from= Category("""(S[dcl]\NP)/NP"""),
      to= Category("""S[dcl]/NP""")
    ),
    TypeChangeUnary(
      from= Category("""((S[dcl]\NP)/(S[dcl]\NP))/NP"""),
      to= Category("""(S[dcl]\NP)/(S[dcl]\NP)""")
    ),
    TypeChangeUnary(
      from= Category("""S[dcl]\NP"""),
      to= Category("""NP/NP""")
    ),
    TypeChangeUnary(
      from= Category("""S[dcl]"""),
      to= Category("""S/(S/S)""")
    ),
    TypeChangeUnary(
      from= Category("""S[dcl]/NP"""),
      to= Category("""NP/NP""")
    ),
    TypeChangeUnary(
      from= Category("""(S/S)\NP"""),
      to= Category("""S/S""")
    ),
    TypeChangeUnary(
      from= Category("""M"""),
      to= Category("""NP/NP""")
    ),
    TypeChangeUnary(
      from= Category("""S[dcl]\NP"""),
      to= Category("""(S[dcl]\NP)\((S[dcl]\NP)/(S[dcl]\NP))""")
    ),
    TypeChangeUnary(
      from= Category("""S[dcl]"""),
      to= Category("""S/S""")
    ),
    TypeChangeUnary(
      from= Category("""S[dcl]"""),
      to= Category("""NP/NP""")
    ),
    TypeChangeUnary(
      from= Category("""((S\NP)/(S\NP))\NP"""),
      to= Category("""(S\NP)/(S\NP)""")
    )
  )

  private var allPredefinedVar : List[CombinatorUnary] = (a_star_predefined ++ c_and_c_additional).distinct
  def allPredefined : List[CombinatorUnary] = allPredefinedVar
  private val allPredefinedTypeRaiseLookupVar = MutMap[(Boolean, Category, Category), TypeRaiser]()
  def allPredefinedTypeRaiseLookup(fwd:Boolean, from:Category, result:Category) : Option[TypeRaiser] = {
    assert(allPredefinedTypeRaiseLookupVar.nonEmpty)
    allPredefinedTypeRaiseLookupVar.get((fwd, from, result.removeFeatures))
  }

  private[combinators] def setLanguage(lang:String, combinatorsContainer: CombinatorsContainer) : Unit = {
    allPredefinedVar = lang match {
      case "English" | "English_CandC" =>
        a_star_predefined ++ c_and_c_additional
      case "English_EasyCCG" =>
        a_star_predefined
      case "Chinese" =>
        chinese_predefined
      case "General" =>
        combinatorsContainer.allUnary.toList
    }
    allPredefinedVar = allPredefinedVar.distinct
    allPredefinedVar.foreach{
      case t@TypeRaiser(from, result, Slash.FWD, true) => allPredefinedTypeRaiseLookupVar((true , from, result.removeFeatures)) = t
      case t@TypeRaiser(from, result, Slash.BCK, true) => allPredefinedTypeRaiseLookupVar((false, from, result.removeFeatures)) = t
      case _ =>
    }
  }

}

trait CombinatorUnary extends Combinator {

  def isUnaryCoordination: Boolean

  def canApply(x: Category): Boolean

  def apply(x: Category): Category

}

