package edin.ccg.arg_cluster_coord

import java.io.PrintWriter

import scala.collection.mutable.ArrayBuffer
import edin.algorithms.AutomaticResourceClosing.linesFromFile
import edin.ccg.representation.DerivationsLoader
import edin.ccg.representation.combinators.{B1bck, Combinator, ConjunctionTop, RemovePunctuation}
import edin.ccg.representation.tree.{BinaryNode, TerminalNode, TreeNode, UnaryNode}

object MainEval {

  private val yes_accGoldFile = "/home/milos/Projects/CCG-translator/data/regents_ficler_goldberg/regents_acc.txt"
  private val non_accGoldFile = "/home/milos/Projects/CCG-translator/data/regents_ficler_goldberg/regents_not_acc.txt"

  private val yes_acc_example = "A restaurant served ([9 pizzas] [during lunch]) and ([6] [during dinner]) today ."
  private val non_acc_example = "He (went to the orchard) and (picked peaches to stock up) ."

  def main2(args: Array[String]) : Unit = {
    System.err.println("extracting sentences START")
    for(inFn <- List(yes_accGoldFile, non_accGoldFile)){
      val outFn = inFn.replaceAll(".txt$", ".words")
      System.err.println(s"writing to $outFn")
      val pw = new PrintWriter(outFn)
      for(line <- linesFromFile(inFn)){
        pw.println(extractSent(tokenize(line)) mkString " ")
      }
      pw.close()
    }
    System.err.println("extracting sentences DONE")
  }

  private def printGeneralInfo() : Unit = {
    // results on ACCour
    // from https://arxiv.org/pdf/1606.00294.pdf
    // on data from https://github.com/Jess1ca/ArgumentClusters/tree/master/regents

    println("r=(47.0 , 54.3 )  ----- all coordination (ATB and non-ATB) recall")

    println("r=(24.1 , 64.8 )  ----- ATB recall from Table 3 for 'structures' (all brackets are correct independently of labels)")
    println("r=(58.29, 72.46)  ----- recovering ATB elements (square brackets) at all (no matter if it's recognized as coordination)")
    println("r=(61.5 , 80.0 )  ----- if round brackets are correct in ATB then what percentage of SQUARE BRACKETS is correct?")

    println("if ROUND brackets of ACC dataset are okay, how often are they labeled correctly (ACC)?")
    println("p=83.78  r=57.40")
    println("restricting further, how often are also square brackets correct?")
    println("p=70.27  r=48.14")
  }

  def main(args: Array[String]) : Unit = {

    for( (tree_new, tree_old) <-
        DerivationsLoader.fromFile("./data/regents_ficler_goldberg/pred_disc-new-revealing-dr0/regents_all.words.16.trees")
        zip
        DerivationsLoader.fromFile("./data/regents_ficler_goldberg/pred_disc-old-revealing-dr0/regents_all.words.16.trees")
    ){
      tree_new.visualize("new")
      tree_old.visualize("old")
      println("Hello")
    }


    val Array(ccgFile) = args

    val goldYesAcc = linesFromFile(yes_accGoldFile).toList.map(tokenize).map(tokens => extractSent(tokens) -> extractCoordInfo(tokens)).toMap
    val goldNonAcc = linesFromFile(non_accGoldFile).toList.map(tokenize).map(tokens => extractSent(tokens) -> extractCoordInfo(tokens)).toMap

    Combinator.setLanguage("English", null)

    // coord

    for(tree <- DerivationsLoader.fromFile(ccgFile)){
      val predCoord = extractCoordInfo(tree)
      val (goldCoord, isAcc) = if(goldYesAcc.contains(tree.words)){
        (goldYesAcc(tree.words), true)
      }else{
        (goldNonAcc(tree.words), false)
      }


    }
    printGeneralInfo()
  }

  private def extractCoordInfo(tree:TreeNode) : List[(Int, Int, List[(Int, Int)])] =
    tree.allNodes.flatMap{
      case BinaryNode(ConjunctionTop(), left, BinaryNode(_, _, right)) => List(cleanPunc(left), cleanPunc(right))
      case _ => Nil
    }.map(accsSpans)

  private def accsSpans(node : TreeNode) : (Int, Int, List[(Int, Int)]) =
    accs(node) match {
      case el::Nil => (node.span._1, node.span._2, Nil            )
      case els     => (node.span._1, node.span._2, els.map(_.span))
    }

  private val accs : TreeNode => List[TreeNode] = {
    case BinaryNode(B1bck(_), left, right) =>
      accs(left) :+ right
    case node =>
      node :: Nil
  }

  private val cleanLeftPunc : TreeNode => TreeNode = {
    case BinaryNode(RemovePunctuation(true), _, node) => cleanLeftPunc(node)
    case BinaryNode(c, l, r) => BinaryNode(c, cleanLeftPunc(l), r)
    case UnaryNode(c, node) => UnaryNode(c, cleanLeftPunc(node))
    case node@TerminalNode(_, _) => node
  }

  private val cleanRightPunc : TreeNode => TreeNode = {
    case BinaryNode(RemovePunctuation(false), node, _) => cleanRightPunc(node)
    case BinaryNode(c, l, r) => BinaryNode(c, l, cleanRightPunc(r))
    case UnaryNode(c, node) => UnaryNode(c, cleanRightPunc(node))
    case node@TerminalNode(_, _) => node
  }

  private val cleanPunc : TreeNode => TreeNode = cleanLeftPunc andThen cleanRightPunc

  private def extractSent(tokens:List[String]) : List[String] = tokens.filterNot(_ matches """^\(|\)|\[|\]$""")

  private def extractCoordInfo(tokens:List[String]) : List[(Int, Int, List[(Int, Int)])] =
    tokens.mkString(" ") match {
      case "He ( went to a sporting goods store ) and ( bought a ( baseball glove ) , ( baseball ) , and ( bat ) ) ." =>
        (1, 7, Nil) :: (8, 17, Nil) :: (10, 12, Nil) :: (13, 14, Nil) :: (16, 17, Nil) :: Nil
      case "( Mike picked 7 apples ) , ( Nancy picked 3 apples ) , and ( Keith picked ( 6 apples ) and ( 4 pears ) ) , at the farm ." =>
        (0, 4, Nil) :: (5,  9, Nil) :: (11, 18, Nil) :: (13, 15, Nil) :: (16, 18, Nil) :: Nil
      case "( Fred picked 36 limes ) , ( Alyssa picked 32 limes ) , and ( Nancy picked ( 35 limes ) and ( 18 pears ) ) , at the farm ." =>
        (0, 4, Nil) :: (5,  9, Nil) :: (11, 18, Nil) :: (13, 15, Nil) :: (16, 18, Nil) :: Nil
      case "He ( went to a sporting goods store ) and ( bought ( a baseball glove ) , ( baseball ) , and ( bat ) ) ." =>
        (1, 7, Nil) :: (8, 17, Nil) :: ( 9, 12, Nil) :: (13, 14, Nil) :: (16, 17, Nil) :: Nil
      case _ =>
        val result = ArrayBuffer[(Int, Int, List[(Int, Int)])]()
        var currPos = 0
        var currCoordStart = -1
        var currArgStart = -1
        var currArgs = ArrayBuffer[(Int, Int)]()

        tokens.foreach{
          case "(" =>
            assert(currCoordStart == -1)
            currCoordStart=currPos
          case ")" =>
            result.append((currCoordStart, currPos, currArgs.toList))
            currArgs = ArrayBuffer()
            currCoordStart = -1
          case "[" =>
            assert(currArgStart == -1)
            currArgStart=currPos
          case "]" =>
            currArgs.append((currArgStart, currPos))
            currArgStart = -1
          case _   =>
            currPos+=1
        }
        result.toList
    }

  private def tokenize(s:String) : List[String] =
    s.replaceAll("""\(|\)|\[|\]""", " $0 ").
      split(" +").
      toList.
      filter(_!="")

}
