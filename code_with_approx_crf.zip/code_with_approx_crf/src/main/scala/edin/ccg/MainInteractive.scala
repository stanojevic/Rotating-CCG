package edin.ccg

import edin.ccg.parsing.RevealingModel
import edin.ccg.representation.combinators.Combinator
import edin.ccg.representation.predarg.PredArg
import edin.general.PTBtokenizer
import edin.nn.DynetSetup

import java.io.File

import edin.ccg.representation.DerivationsLoader

import scala.collection.JavaConverters._
import edin.ccg.representation.tree.TreeNode
import uk.ac.ed.easyccg.main.EasyCCG.InputFormat
import uk.ac.ed.easyccg.syntax.{ParserAStar, TaggerEmbeddings}

import scala.io.StdIn.readLine

object MainInteractive {

  case class CMDargs(
                      model_dir         : String         = null,
                      language          : String         = "English",
                    )

  def main(args:Array[String]) : Unit = {
    val parser = new scopt.OptionParser[CMDargs](PROGRAM_NAME) {
      head(PROGRAM_NAME, PROGRAM_VERSION.toString)
      opt[ String ]("modelDir" ).action((x,c) => c.copy( model_dir           = x )).required()
      opt[ String ]("language" ).action((x,c) => c.copy( language             = x ))
      help("help").text("prints this usage text")
    }

    trait Parser{
      def parse(words:List[String]) : TreeNode
    }
    class MyParser(modelDir:String) extends Parser {
      DynetSetup.init_dynet()
      private val model = new RevealingModel()
      model.loadFromModelDir(modelDir)

      override def parse(words: List[String]): TrainInstance = {
        DynetSetup.cg_renew()
        edin.ccg.parsing.Parser.parse(
          sent         = words,
          beamType     = "simple",
          beamRescaled = false,
          kMidParsing  = 1,
          kOutParsing  = 1,
          kOutWord     = 1,
          kOutTagging  = 1,
          maxStackSize = Int.MaxValue
        )(model::Nil)
      }
    }
    class EasyCCGmodel(modelDir:String) extends Parser {


      private val parser = new ParserAStar(
        new TaggerEmbeddings(
          new File(modelDir),
          100,
          0.0001,
          50
        ),
        100,
        1,
        0.0,
        InputFormat.valueOf("TOKENIZED"),
        List("S[dcl]", "S[wq]", "S[q]", "S[qem]", "NP").asJava,
        new File(new File(modelDir), "unaryRules"),
        new File(new File(modelDir), "binaryRules"),
        new File(new File(modelDir), "seenRules")
      )

      def parse(words:List[String]) : TreeNode =
        DerivationsLoader.fromString(parser.parse(words.mkString(" ")).get(0).toString)

    }


    parser.parse(args, CMDargs()) match {
      case Some(cmd_args) =>

        val parser : Parser = if(new File(cmd_args.model_dir+"/suffix").exists()){
          // EasyCCG
          new EasyCCGmodel(cmd_args.model_dir)
        }else{
          // my model
          new MyParser(cmd_args.model_dir)
        }

        Combinator.setLanguage(cmd_args.language, null)

        PredArg.includeConjunctInDeps = true

        while(true){
          val sentStr = readLine("> ")
          if(sentStr == "EXIT"){
            System.exit(0)
          }else if(sentStr startsWith "(<T "){
            val tree = DerivationsLoader.fromString(sentStr)
            tree.visualize()
            tree.depsVisualize()
          }else{
            val words = PTBtokenizer.tokenize(sentStr)
            println(words.mkString(" "))
            val tree = parser.parse(words)
            tree.visualize()
            tree.depsVisualize()
          }
        }
      case None =>
        System.err.println("You didn't specify all the required arguments")
        System.exit(-1)
    }
  }

}
