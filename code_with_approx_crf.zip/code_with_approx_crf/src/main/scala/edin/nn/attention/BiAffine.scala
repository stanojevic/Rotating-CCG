package edin.nn.attention

import edu.cmu.dynet.{Expression, ParameterCollection}
import edin.nn.DyFunctions._
import edin.general.RichScala._
import edin.nn.model.YamlConfig

final case class BiAffineConfig(
                                 dim       : Int,
                                 labels    : Int,
                               ) {
  def construct()(implicit model:ParameterCollection): BiAffine =
    new BiAffine(this)
}

object BiAffineConfig{

  def fromYaml(conf:YamlConfig) : BiAffineConfig =
    BiAffineConfig(
      dim = conf("dim").int,
      labels = conf("labels").int
    )

}

class BiAffine(val config:BiAffineConfig)(implicit model:ParameterCollection) {

  import config._

  private val dimX = dim+1
  private val dimY = dim+1

  private val W = addParameters((dimY*labels, dimX), initAround(0))

  def apply(x:Expression, y:Expression) : Expression = {
    val n = x.cols
    val b = x.batchSize

    val X = concat(x, ones(1, n))
    val Y = concat(y, ones(1, n))

    if (labels == 1){
      Y.T * W * X
    }else{
      (  W*X                             ) |>
      (  _ reshape ((dimY, labels*n), b) ) |>
      (  Y.T*_                           ) |>
      (  _ reshape ((n, labels, n), b)   )
    }
  }

}
