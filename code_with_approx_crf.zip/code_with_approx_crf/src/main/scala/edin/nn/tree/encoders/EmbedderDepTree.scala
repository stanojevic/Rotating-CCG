package edin.nn.tree.encoders

import edin.dependencies.DepNode
import edin.nn.DyFunctions._
import edin.nn._
import edin.nn.embedder.EmbedderStandardConfig
import edin.nn.layers.{Dropout, SingleLayer}
import edin.nn.model.Any2Int
import edu.cmu.dynet.{Expression, ParameterCollection}

/*
** This is OOOOOOLD
 */

sealed case class EmbedderDepTreeConfig(
                                       w2i         : Any2Int[String],
                                       p2i         : Any2Int[String],
                                       e2i         : Any2Int[String],
                                       wDim        : Int,
                                       pDim        : Int,
                                       eDim        : Int,
                                       nodeDim     : Int,
                                       wDropout    : Float,
                                       pDropout    : Float,
                                       eDropout    : Float,
                                       nodeDropout : Float
                                       ){
  def construct()(implicit model: ParameterCollection) = new EmbedderDepTree(this)
}


final case class EmbedderDepTreeState(h:Expression) extends StateClosed

// Not your typical embedder : doesn't implement Embedder interface
class EmbedderDepTree(c:EmbedderDepTreeConfig)(implicit model:ParameterCollection){

  private val wDropout    = Dropout(c.wDropout)
  private val pDropout    = Dropout(c.pDropout)
  private val eDropout    = Dropout(c.eDropout)
  private val nodeDropout = Dropout(c.nodeDropout)

  private val wE = EmbedderStandardConfig(
    s2i       = c.w2i,
    outDim    = c.wDim,
    dropout   = c.wDropout
  ).construct()
  private val pE = EmbedderStandardConfig(
    s2i       = c.p2i,
    outDim    = c.pDim,
    dropout   = c.pDropout
  ).construct()
  private val eE = EmbedderStandardConfig(
    s2i       = c.e2i,
    outDim    = c.eDim,
    dropout   = c.eDropout
  ).construct()

  private val compressor = SingleLayer.compressor(c.wDim + c.pDim + c.eDim , c.nodeDim)

  def embed(root: DepNode): Unit =
    for(node <- root.allNodes){
      val wEmb = wDropout(wE(node.word))
      val pEmb = pDropout(pE(node.posTag))
      val eEmb = eDropout(eE(node.relation))
      val h = nodeDropout(compressor(concat(wEmb, pEmb, eEmb)))
      val state = EmbedderDepTreeState(h)
      node.nn   = state
    }

}

