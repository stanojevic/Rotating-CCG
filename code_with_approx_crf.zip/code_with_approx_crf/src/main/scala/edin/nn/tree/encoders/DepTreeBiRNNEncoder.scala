package edin.nn.tree.encoders

import edin.dependencies.DepNode
import edin.nn._
import edin.nn.sequence.{MultiUniDirRNN, MultiUniDirRNNConfig}
import edin.nn.tree.EncodableNode
import edu.cmu.dynet.ParameterCollection

sealed case class DepTreeBiRNNEncoderConfig(
                                             inDim          : Int,
                                             outDim         : Int,
                                             seqType        : String,
                                             seqLayers      : Int,
                                             withLayerNorm  : Boolean,
                                             seqDropout     : Float
                                           ){
  def construct()(implicit model: ParameterCollection) = new DepTreeBiRNNEncoder(this)
}


class DepTreeBiRNNEncoder(c:DepTreeBiRNNEncoderConfig)(implicit model: ParameterCollection) extends TreeEncoder {

  private val rnn = MultiUniDirRNNConfig(
    rnnType           = c.seqType,
    inDim             = c.inDim,
    outDim            = c.outDim,
    layers            = c.seqLayers,
    withResidual      = false,
    withLayerNorm     = c.withLayerNorm,
    dropProb = c.seqDropout
  ).construct()

  override def reencode(root: EncodableNode): Unit = {
    val allNodes   = root.asInstanceOf[DepNode].allNodesLinear
    val oldVectors = allNodes.map{_.nn.h}
    val newVectors = rnn.transduce(oldVectors)
    (allNodes zip newVectors).foreach{ case (node, vec) => node.nn = SimpleState(vec) }
  }

}
